import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

import repositorio_usuario


class Usuarios:
    def __init__(self):
        self.builder = Gtk.Builder()
        self.builder.add_from_file("usuarios.glade")
        self.builder.connect_signals(self)

        self.janela = self.builder.get_object("janela_usuarios")
        self.entry_nome = self.builder.get_object("entry_nome")
        self.entry_login = self.builder.get_object("entry_login")
        self.entry_senha = self.builder.get_object("entry_senha")
        self.store = self.builder.get_object("store_usuarios")
        self.tree = self.builder.get_object("tree_usuarios")
        self.lbl_status = self.builder.get_object("lbl_status")

        self.id_editando = None
        self.carregar_lista()
        self.janela.show_all()

    def carregar_lista(self):
        self.store.clear()
        for id_usuario, nome, login in repositorio_usuario.listar():
            self.store.append([id_usuario, nome, login])

    def limpar(self):
        self.id_editando = None
        self.entry_nome.set_text("")
        self.entry_login.set_text("")
        self.entry_senha.set_text("")

    def on_btn_salvar_clicked(self, widget):
        nome = self.entry_nome.get_text().strip()
        login = self.entry_login.get_text().strip()
        senha = self.entry_senha.get_text()

        if not nome or not login:
            self.lbl_status.set_text("Preencha nome e login.")
            return
        if self.id_editando is None and not senha:
            self.lbl_status.set_text("Informe a senha do novo usuário.")
            return

        try:
            if self.id_editando is None:
                repositorio_usuario.inserir(nome, login, senha)
                self.lbl_status.set_text("Usuário cadastrado.")
            else:
                repositorio_usuario.atualizar(self.id_editando, nome, login, senha)
                self.lbl_status.set_text("Usuário atualizado.")
        except Exception as erro:
            self.lbl_status.set_text(f"Erro: {erro}")
            return

        self.limpar()
        self.carregar_lista()

    def on_btn_editar_clicked(self, widget):
        modelo, linha = self.tree.get_selection().get_selected()
        if linha is None:
            self.lbl_status.set_text("Selecione um usuário na lista.")
            return
        self.id_editando = modelo[linha][0]
        self.entry_nome.set_text(modelo[linha][1])
        self.entry_login.set_text(modelo[linha][2])
        self.entry_senha.set_text("")
        self.lbl_status.set_text("Editando. Digite uma senha nova e clique em Salvar.")

    def on_btn_excluir_clicked(self, widget):
        modelo, linha = self.tree.get_selection().get_selected()
        if linha is None:
            self.lbl_status.set_text("Selecione um usuário na lista.")
            return
        repositorio_usuario.excluir(modelo[linha][0])
        self.limpar()
        self.carregar_lista()
        self.lbl_status.set_text("Usuário excluído.")

    def on_btn_limpar_clicked(self, widget):
        self.limpar()
        self.lbl_status.set_text("")

    def on_janela_usuarios_destroy(self, widget):
        Gtk.main_quit()


if __name__ == "__main__":
    Usuarios()
    Gtk.main()
