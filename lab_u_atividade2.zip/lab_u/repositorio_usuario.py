import hashlib
import hmac
import secrets

from conexao import conectar

ITERACOES = 200_000  # o mesmo valor no cadastro e no login


# ---------- senha ----------

def calcular_hash(senha, salt_hex):
    """Única função que calcula o hash (usada no cadastro e no login).
    Recebe a senha (texto) e o salt em hexadecimal; devolve o hash em hex (64 caracteres)."""
    resultado = hashlib.pbkdf2_hmac(
        "sha256",
        senha.encode("utf-8"),
        bytes.fromhex(salt_hex),
        ITERACOES,
    )
    return resultado.hex()


def preparar_senha(senha):
    """Devolve (senha_hash, salt). O salt é novo a cada chamada.
    A senha digitada não é guardada em lugar nenhum."""
    salt = secrets.token_bytes(16).hex()      # 16 bytes -> 32 caracteres hex
    senha_hash = calcular_hash(senha, salt)   # 64 caracteres hex
    return senha_hash, salt


# ---------- CRUD ----------

def inserir(nome, login, senha):
    senha_hash, salt = preparar_senha(senha)
    conexao = conectar()
    cursor = conexao.cursor()
    try:
        cursor.execute(
            "INSERT INTO usuarios (nome, login, senha_hash, salt) VALUES (%s, %s, %s, %s)",
            (nome, login, senha_hash, salt),
        )
        conexao.commit()
    finally:
        cursor.close()
        conexao.close()


def atualizar(id_usuario, nome, login, senha):
    """Se a senha vier vazia, mantém a senha atual; senão grava novo hash e novo salt."""
    conexao = conectar()
    cursor = conexao.cursor()
    try:
        if senha:
            senha_hash, salt = preparar_senha(senha)
            cursor.execute(
                "UPDATE usuarios SET nome = %s, login = %s, senha_hash = %s, salt = %s WHERE id = %s",
                (nome, login, senha_hash, salt, id_usuario),
            )
        else:
            cursor.execute(
                "UPDATE usuarios SET nome = %s, login = %s WHERE id = %s",
                (nome, login, id_usuario),
            )
        conexao.commit()
    finally:
        cursor.close()
        conexao.close()


def excluir(id_usuario):
    conexao = conectar()
    cursor = conexao.cursor()
    try:
        cursor.execute("DELETE FROM usuarios WHERE id = %s", (id_usuario,))
        conexao.commit()
    finally:
        cursor.close()
        conexao.close()


def listar():
    """Devolve lista de (id, nome, login). Nunca devolve hash nem salt."""
    conexao = conectar()
    cursor = conexao.cursor()
    try:
        cursor.execute("SELECT id, nome, login FROM usuarios ORDER BY nome")
        return cursor.fetchall()
    finally:
        cursor.close()
        conexao.close()


# ---------- login ----------

def verificar_login(login, senha):
    """Devolve o nome do usuário se login e senha conferem; None caso contrário."""
    conexao = conectar()
    cursor = conexao.cursor()
    try:
        cursor.execute(
            "SELECT nome, senha_hash, salt FROM usuarios WHERE login = %s",
            (login,),
        )
        linha = cursor.fetchone()
    finally:
        cursor.close()
        conexao.close()

    if linha is None:
        return None

    nome, senha_hash_banco, salt = linha
    senha_hash_digitada = calcular_hash(senha, salt)

    if hmac.compare_digest(senha_hash_digitada, senha_hash_banco):
        return nome
    return None
