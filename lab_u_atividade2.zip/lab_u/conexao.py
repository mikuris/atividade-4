import mysql.connector

# Ajuste usuário e senha do MySQL da sua máquina.
CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "lab_u",
}


def conectar():
    return mysql.connector.connect(**CONFIG)
