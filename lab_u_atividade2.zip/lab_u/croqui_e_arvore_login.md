# Croqui da tela de login (redesenhem à mão para a entrega)

```
+--------------------------------------+
| Login                          [_][x]|
+--------------------------------------+
|        Login do Sistema              |
|                                      |
|  Login:                              |
|  [______________________________]    |   entry_login
|  Senha:                              |
|  [******************************]    |   entry_senha
|                                      |
|  [           Entrar            ]     |   btn_entrar
|                                      |
|  Login válido. Bem-vindo(a), Ana!    |   lbl_mensagem
+--------------------------------------+
```

# Árvore de objetos

```
janela_login (GtkWindow)
└── caixa_principal (GtkBox, vertical)
    ├── lbl_titulo (GtkLabel)       "Login do Sistema"
    ├── lbl_login (GtkLabel)        "Login:"
    ├── entry_login (GtkEntry)      signal activate -> on_btn_entrar_clicked
    ├── lbl_senha (GtkLabel)        "Senha:"
    ├── entry_senha (GtkEntry)      visibility = False; signal activate -> on_btn_entrar_clicked
    ├── btn_entrar (GtkButton)      "Entrar"; signal clicked -> on_btn_entrar_clicked
    └── lbl_mensagem (GtkLabel)     resultado do login
```

Sinais: `on_btn_entrar_clicked` (botão e Enter nos campos), `on_janela_login_destroy` (fecha o programa).
