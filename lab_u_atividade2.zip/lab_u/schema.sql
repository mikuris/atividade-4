CREATE DATABASE IF NOT EXISTS lab_u CHARACTER SET utf8mb4;
USE lab_u;

CREATE TABLE IF NOT EXISTS usuarios (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    nome       VARCHAR(100) NOT NULL,
    login      VARCHAR(50)  NOT NULL UNIQUE,
    senha_hash CHAR(64)     NOT NULL,
    salt       CHAR(32)     NOT NULL
);
