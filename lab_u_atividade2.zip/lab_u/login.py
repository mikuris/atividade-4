import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

import repositorio_usuario  # a verificação (e o SQL) ficam lá


class Login:
    def __init__(self):
        self.builder = Gtk.Builder()
        self.builder.add_from_file("login.glade")
        self.builder.connect_signals(self)

        self.janela = self.builder.get_object("janela_login")
        self.entry_login = self.builder.get_object("entry_login")
        self.entry_senha = self.builder.get_object("entry_senha")
        self.lbl_mensagem = self.builder.get_object("lbl_mensagem")

        self.janela.show_all()

    def mostrar(self, texto):
        self.lbl_mensagem.set_text(texto)
        print(texto)

    def on_btn_entrar_clicked(self, widget):
        login = self.entry_login.get_text().strip()
        senha = self.entry_senha.get_text()

        if login == "" or senha == "":
            self.mostrar("Preencha o login e a senha.")
            return

        nome = repositorio_usuario.verificar_login(login, senha)

        if nome is not None:
            self.mostrar(f"Login válido. Bem-vindo(a), {nome}!")
        else:
            self.mostrar("Usuário ou senha inválidos.")

    def on_janela_login_destroy(self, widget):
        Gtk.main_quit()


if __name__ == "__main__":
    Login()
    Gtk.main()
